#pragma once
#include <string>

class MyJSON
{
public:
	virtual std::string toJSON() = 0;
};