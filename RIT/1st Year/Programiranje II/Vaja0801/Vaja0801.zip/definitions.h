#pragma once

typedef unsigned int uint;