#include <fstream>
#include <iostream>
#include <random>
#include <chrono>
#include "ArrayList.h"


using namespace std;
using namespace timiimit::GenericStructures;

typedef unsigned char byte;
typedef unsigned int uint;

template<class T = byte>
void RadixSortSlow(T* arr, size_t count)
{
	size_t bits = sizeof(T) * 8;
	ArrayList<T> zero = ArrayList<T>(count);
	ArrayList<T> one = ArrayList<T>(count);

	for (size_t bit = 0; bit < bits; bit++)
	{
		// put in buckets
		for (size_t i = 0; i < count; i++)
		{
			if (((arr[i] >> bit) & 1))
			{
				one.Add(arr[i]);
			}
			else
			{
				zero.Add(arr[i]);
			}
		}

		// take out of buckets;
		size_t zerosize = zero.GetSize();
		size_t onesize = one.GetSize();
		for (size_t i = 0; i < zerosize; i++)
		{
			arr[i] = zero.GetData()[i];
		}
		for (size_t i = 0; i < onesize; i++)
		{
			arr[i + zerosize] = one.GetData()[i];
		}

		zero.Clear();
		one.Clear();
	}
}

template<class T = byte>
void RadixSort(T* arr, size_t count)
{
	T* arrend = arr + count;
	size_t bits = sizeof(T) * 8;
	//ArrayList<T> zero = ArrayList<T>(count);
	//ArrayList<T> one = ArrayList<T>(count);
	T* zeroarr = new T[count];// zero.GetData();
	T* onearr = new T[count];// one.GetData();

	T* iter;
	T* zeroiter = zeroarr;
	T* zeroiter2 = zeroiter;
	T* oneiter = onearr;
	T* oneiter2 = oneiter;


	for (byte bit = 0; bit < bits; bit++)
	{
		zeroiter2 = zeroiter = zeroarr;
		oneiter2 = oneiter = onearr;

		// put in buckets
		iter = arr;
		while (iter < arrend)
		{
			if (((*iter >> bit) & 1))
			{
				//one.Add(arr[i])
				*oneiter = *iter;
				oneiter++;
			}
			else
			{
				//zero.Add(arr[i]);
				*zeroiter = *iter;
				zeroiter++;
			}
			iter++;
		}

		iter = arr;

		// take out of buckets;
		while (zeroiter2 < zeroiter)
		{
			*iter = *zeroiter2;
			iter++;
			zeroiter2++;
		}
		while (oneiter2 < oneiter)
		{
			*iter = *oneiter2;
			iter++;
			oneiter2++;
		}
	}
}

template<class T>
void Print(T* arr, size_t count)
{
	for (size_t i = 0; i < count; i++)
	{
		cout << arr[i] << " ";
	}
	cout << endl;
}

#define MEASURETIME(x, time) { auto start = std::chrono::system_clock::now(); x; auto end=std::chrono::system_clock::now(); time = std::chrono::duration_cast<std::chrono::microseconds>(end - start).count() / 1000.0; }

byte* ReadInts(const char* const filename, size_t* count)
{
	ifstream in(filename);
	if (in.is_open())
	{
		ArrayList<byte> arr(100, 100);
		int num;
		while (in.good())
		{
			in >> num;
			arr.Add((byte)num);
		}
		byte* ret = new byte[arr.GetSize()];
		memcpy(ret, arr.GetData(), sizeof(byte) * arr.GetSize());
		*count = arr.GetSize();
		return ret;
	}
	return nullptr;
}

void WriteInts(const char* const filename, const byte* const ints, const size_t count)
{
	ofstream out(filename);
	if (out.is_open())
	{
		for (size_t i = 0; i < count; i++)
		{
			out << (int)ints[i] << " ";
		}
	}
	delete[] ints;
}

int main(int argc, char** argv)
{
	if (argc != 2)
		return 1;

	size_t count;
	byte* ints = ReadInts(argv[1], &count);
	if (!ints)
		return 2;
	
	//double avg = 0;
	//for (size_t i = 0; i < 100; i++)
	//{
	//	double time;
	//	MEASURETIME(RadixSort(ints, count), time);
	//	avg += time;
	//}
	//cout << "sort time: " << (avg/100) << "ms" << endl;
	RadixSort(ints, count);

	WriteInts("out.txt", ints, count);
	
	return 0;
}